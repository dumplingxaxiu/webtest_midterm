chạy toàn bộ modules (1-4): robot *.robot
